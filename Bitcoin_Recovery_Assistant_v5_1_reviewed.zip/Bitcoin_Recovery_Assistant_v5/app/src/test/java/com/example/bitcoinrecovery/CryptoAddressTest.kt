package com.example.bitcoinrecovery

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CryptoAddressTest {
    @Test fun validatesTheConfiguredLegacyTargetAddress() {
        assertEquals(
            AddressType.LEGACY,
            Crypto.validateAddress("12ib7dApVFvg82TXKycWBNpN8kFyiAN1dr")
        )
    }

    @Test fun rejectsAnAddressWithAnInvalidChecksum() {
        assertThrows(IllegalArgumentException::class.java) {
            Crypto.validateAddress("12ib7dApVFvg82TXKycWBNpN8kFyiAN1ds")
        }
    }

    @Test fun base58EncodingRoundTripsLeadingZeroBytes() {
        val bytes = byteArrayOf(0, 0, 1, 2, 3, 4)
        assertEquals(bytes.toList(), Crypto.base58Decode(Crypto.base58Encode(bytes)).toList())
    }

    @Test fun bip44XpubDerivesTheExpectedLegacyAddress() = assertDerivedAddress(
        "xpub6BemYiVNp19ZzDy4pSiU3c91o45WETeet9pQobsgDceXNo42Gdc8kyUoTT6deBq8L5WrHXMtkDDe7Ce9GgWjMRprWJk1jYxArimSXN6B3Uq",
        AddressType.LEGACY,
        "1NQpH6Nf8QtR2HphLRcvuVqfhXBXsiWn8r"
    )

    @Test fun bip49YpubDerivesTheExpectedNestedSegwitAddress() = assertDerivedAddress(
        "ypub6WV2rPAHxgh3s439gJDcHWuzh96DtKAkERuQHng33PGcECp8poaRdiAyi8JQXbrxypNN8G8potjaEFhSE3byDmQEcnCTLW854gEhVFsQpCH",
        AddressType.NESTED_SEGWIT,
        "35KsULTNUcaFcJC3aKBnP38ZZW2Yu36khW"
    )

    @Test fun bip84ZpubDerivesTheExpectedNativeSegwitAddress() = assertDerivedAddress(
        "zpub6qKJA3qD7NEXi4KvkrvCe6WdVtY67WkmtdS3SS87KLm9stMaZimapHXJdRQGQRHoqru6YFewF3qk6BLyc13UFzc1k2erNRxSGc5cQKyZqDg",
        AddressType.NATIVE_SEGWIT,
        "bc1qpux3z758ulsxg69eptaakukraanqwtdxe5yy4c"
    )

    private fun assertDerivedAddress(key: String, type: AddressType, expected: String) {
        val actual = ExtendedPublicKey.parse(key).derive(0).derive(0).address()
        assertEquals(expected, actual)
        assertEquals(type, Crypto.validateAddress(actual))
    }
}
