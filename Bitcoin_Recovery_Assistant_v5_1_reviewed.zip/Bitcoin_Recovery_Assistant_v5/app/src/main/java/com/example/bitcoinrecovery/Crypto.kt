package com.example.bitcoinrecovery

import java.math.BigInteger
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

internal object Crypto {
    val P = BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F", 16)
    val N = BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141", 16)
    private val Gx = BigInteger("79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798", 16)
    private val Gy = BigInteger("483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8", 16)
    data class Point(val x: BigInteger, val y: BigInteger)
    val G = Point(Gx, Gy)

    fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b)
    fun hash160(b: ByteArray): ByteArray {
        val sha = sha256(b)
        val digest = org.bouncycastle.crypto.digests.RIPEMD160Digest()
        digest.update(sha, 0, sha.size)
        val out = ByteArray(20)
        digest.doFinal(out, 0)
        return out
    }
    fun hmac512(key: ByteArray, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA512")
        mac.init(SecretKeySpec(key, "HmacSHA512"))
        return mac.doFinal(data)
    }
    fun add(a: Point?, b: Point?): Point? {
        if (a == null) return b
        if (b == null) return a
        if (a.x == b.x && a.y.add(b.y).mod(P) == BigInteger.ZERO) return null
        val slope = if (a == b) {
            a.x.multiply(a.x).multiply(BigInteger.valueOf(3))
                .multiply(a.y.multiply(BigInteger.valueOf(2)).modInverse(P)).mod(P)
        } else {
            b.y.subtract(a.y).multiply(b.x.subtract(a.x).mod(P).modInverse(P)).mod(P)
        }
        val x = slope.multiply(slope).subtract(a.x).subtract(b.x).mod(P)
        val y = slope.multiply(a.x.subtract(x)).subtract(a.y).mod(P)
        return Point(x, y)
    }
    fun multiply(k0: BigInteger, point: Point = G): Point? {
        var k = k0.mod(N)
        var addend: Point? = point
        var result: Point? = null
        while (k > BigInteger.ZERO) {
            if (k.testBit(0)) result = add(result, addend)
            addend = add(addend, addend)
            k = k.shiftRight(1)
        }
        return result
    }
    fun fixed32(n: BigInteger): ByteArray {
        val raw = n.toByteArray()
        return when {
            raw.size == 32 -> raw
            raw.size > 32 -> raw.copyOfRange(raw.size - 32, raw.size)
            else -> ByteArray(32 - raw.size) + raw
        }
    }
    fun pub(point: Point): ByteArray =
        byteArrayOf(if (point.y.testBit(0)) 3 else 2) + fixed32(point.x)

    fun decodePub(bytes: ByteArray): Point {
        require(bytes.size == 33 && (bytes[0].toInt() == 2 || bytes[0].toInt() == 3)) { "کلید عمومی فشرده نامعتبر است." }
        val x = BigInteger(1, bytes.copyOfRange(1, 33))
        require(x < P) { "مختصات کلید عمومی خارج از میدان منحنی است." }
        val alpha = x.modPow(BigInteger.valueOf(3), P).add(BigInteger.valueOf(7)).mod(P)
        var y = alpha.modPow(P.add(BigInteger.ONE).shiftRight(2), P)
        val odd = bytes[0].toInt() == 3
        if (y.testBit(0) != odd) y = P.subtract(y)
        require(y.multiply(y).mod(P) == alpha) { "نقطه منحنی نامعتبر است." }
        return Point(x, y)
    }
    fun base58Decode(s: String): ByteArray {
        val alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        var n = BigInteger.ZERO
        for (c in s) {
            val d = alphabet.indexOf(c)
            require(d >= 0) { "کاراکتر نامعتبر Base58." }
            n = n.multiply(BigInteger.valueOf(58)).add(BigInteger.valueOf(d.toLong()))
        }
        var body = n.toByteArray()
        if (body.isNotEmpty() && body[0] == 0.toByte()) body = body.copyOfRange(1, body.size)
        return ByteArray(s.takeWhile { it == '1' }.length) + body
    }
    fun base58Encode(input: ByteArray): String {
        val alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
        var n = BigInteger(1, input)
        val sb = StringBuilder()
        val base = BigInteger.valueOf(58)
        while (n > BigInteger.ZERO) {
            val qr = n.divideAndRemainder(base)
            sb.append(alphabet[qr[1].toInt()])
            n = qr[0]
        }
        for (b in input) { if (b.toInt() == 0) sb.append('1') else break }
        return sb.reverse().toString()
    }
    fun base58Check(payload: ByteArray): String {
        val c = sha256(sha256(payload)).copyOfRange(0, 4)
        return base58Encode(payload + c)
    }

    /** Validates supported mainnet P2PKH, P2SH and native SegWit v0 addresses. */
    fun validateAddress(address: String): AddressType {
        require(address.isNotBlank()) { "آدرس هدف خالی است." }
        if (address.startsWith("bc1", ignoreCase = true)) {
            val normalized = address.lowercase()
            require(address == normalized || address == address.uppercase()) {
                "آدرس Bech32 نباید ترکیبی از حروف کوچک و بزرگ باشد."
            }
            val separator = normalized.lastIndexOf('1')
            require(separator in 1 until normalized.length - 6 && normalized.substring(0, separator) == "bc") {
                "ساختار آدرس Bech32 شبکه اصلی نامعتبر است."
            }
            val alphabet = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
            val values = normalized.substring(separator + 1).map { ch ->
                val value = alphabet.indexOf(ch)
                require(value >= 0) { "کاراکتر نامعتبر در آدرس Bech32." }
                value
            }
            require(bech32Polymod(hrpExpand("bc") + values) == 1) { "Checksum آدرس Bech32 نامعتبر است." }
            val data = values.dropLast(6)
            require(data.isNotEmpty() && data[0] == 0) { "فقط آدرس‌های Native SegWit نسخه صفر پشتیبانی می‌شوند." }
            val program = convertBits(data.drop(1), 5, 8, false)
            require(program.size == 20) { "این برنامه فقط آدرس Native SegWit از نوع P2WPKH را پشتیبانی می‌کند." }
            return AddressType.NATIVE_SEGWIT
        }

        val decoded = base58Decode(address)
        require(decoded.size == 25) { "طول آدرس Base58 نامعتبر است." }
        val payload = decoded.copyOfRange(0, 21)
        val checksum = decoded.copyOfRange(21, 25)
        require(sha256(sha256(payload)).copyOfRange(0, 4).contentEquals(checksum)) {
            "Checksum آدرس بیت‌کوین نامعتبر است."
        }
        return when (payload[0].toInt() and 0xff) {
            0 -> AddressType.LEGACY
            5 -> AddressType.NESTED_SEGWIT
            else -> throw IllegalArgumentException("آدرس متعلق به شبکه اصلی یا قالب پشتیبانی‌شده نیست.")
        }
    }

    private fun bech32Polymod(values: List<Int>): Int {
        val generators = intArrayOf(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
        var checksum = 1
        for (value in values) {
            val top = checksum ushr 25
            checksum = ((checksum and 0x1ffffff) shl 5) xor value
            for (i in 0..4) if (((top ushr i) and 1) != 0) checksum = checksum xor generators[i]
        }
        return checksum
    }
    fun p2pkh(pub: ByteArray): String {
        val h = hash160(pub)
        return base58Check(byteArrayOf(0) + h)
    }

    fun p2shP2wpkh(pub: ByteArray): String {
        val redeemScript = byteArrayOf(0x00, 0x14) + hash160(pub)
        return base58Check(byteArrayOf(5) + hash160(redeemScript))
    }

    fun p2wpkh(pub: ByteArray): String {
        val program = hash160(pub)
        val data = listOf(0) + convertBits(program.map { it.toInt() and 0xff }, 8, 5, true)
        val hrp = "bc"
        val values = hrpExpand(hrp) + data + List(6) { 0 }
        var chk = 1
        val generators = intArrayOf(0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3)
        for (v in values) {
            val top = chk ushr 25
            chk = ((chk and 0x1ffffff) shl 5) xor v
            for (i in 0..4) if (((top ushr i) and 1) != 0) chk = chk xor generators[i]
        }
        chk = chk xor 1
        val checksum = (0 until 6).map { (chk ushr (5 * (5 - it))) and 31 }
        val alphabet = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
        return hrp + "1" + (data + checksum).joinToString("") { alphabet[it].toString() }
    }

    private fun hrpExpand(hrp: String): List<Int> =
        hrp.map { it.code ushr 5 } + listOf(0) + hrp.map { it.code and 31 }

    private fun convertBits(data: List<Int>, from: Int, to: Int, pad: Boolean): List<Int> {
        var acc = 0
        var bits = 0
        val result = mutableListOf<Int>()
        val maxv = (1 shl to) - 1
        for (value in data) {
            require(value >= 0 && (value ushr from) == 0) { "داده نامعتبر برای Bech32." }
            acc = (acc shl from) or value
            bits += from
            while (bits >= to) {
                bits -= to
                result.add((acc ushr bits) and maxv)
            }
        }
        if (pad) {
            if (bits > 0) result.add((acc shl (to - bits)) and maxv)
        } else {
            require(bits < from && ((acc shl (to - bits)) and maxv) == 0) { "Padding نامعتبر Bech32." }
        }
        return result
    }
}
