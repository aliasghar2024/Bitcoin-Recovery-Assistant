package com.example.bitcoinrecovery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val TARGET = "12ib7dApVFvg82TXKycWBNpN8kFyiAN1dr"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { XpubScannerApp() } }
    }
}

@Composable
private fun XpubScannerApp() {
    var target by remember { mutableStateOf(TARGET) }
    var xpub by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("0") }
    var end by remember { mutableStateOf("100") }
    var branch by remember { mutableStateOf("0") }
    var status by remember { mutableStateOf("برای تطبیق آدرس، xpub عمومی حساب خودتان را وارد کنید.") }
    var running by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf<List<String>>(emptyList()) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Bitcoin Recovery Assistant V5.1", style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold)
        Text("موتور مشتق‌سازی BIP32 برای xpub / ypub / zpub")

        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("آدرس هدف", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(target, { target = it.trim() }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Bitcoin address") }, enabled = !running)
                Text("آدرس پیش‌فرض: $TARGET", style = MaterialTheme.typography.bodySmall)
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("کلید عمومی توسعه‌یافته حساب", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(xpub, { xpub = it.trim() }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("xpub... / ypub... / zpub...") }, minLines = 2, enabled = !running)
                Text("xpub را فقط داخل برنامه روی دستگاه خودتان وارد کنید. هرگز آن را همراه با عبارت بازیابی یا کلید خصوصی برای دیگران ارسال نکنید.")
                OutlinedTextField(branch, { branch = it.filter(Char::isDigit).take(2) },
                    label = { Text("Branch (معمولاً 0 دریافت / 1 تغییر)") }, singleLine = true, enabled = !running)
                OutlinedTextField(start, { start = it.filter(Char::isDigit).take(9) },
                    label = { Text("اندیس شروع") }, singleLine = true, enabled = !running)
                OutlinedTextField(end, { end = it.filter(Char::isDigit).take(9) },
                    label = { Text("اندیس پایان") }, singleLine = true, enabled = !running)
                val s = start.toLongOrNull()
                val e = end.toLongOrNull()
                val b = branch.toLongOrNull()
                val valid = s != null && e != null && b != null && s <= e &&
                    e - s + 1 <= 10000 && e <= 2147483647 && b in 0..1
                Button(enabled = valid && xpub.isNotBlank() && !running, onClick = {
                    running = true
                    status = "در حال بررسی..."
                    matches = emptyList()
                    // Scanner is intentionally run in a coroutine in the UI scope below.
                }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "در حال بررسی..." else "شروع تطبیق xpub با آدرس") }
                if (running) {
                    LaunchedEffect(running) {
                        if (!running) return@LaunchedEffect
                        val scanXpub = xpub
                        val scanTarget = target
                        val scanStart = s!!
                        val scanEnd = e!!
                        val scanBranch = b!!
                        val result = withContext(Dispatchers.Default) {
                            try {
                                val root = ExtendedPublicKey.parse(scanXpub)
                                val targetType = Crypto.validateAddress(scanTarget)
                                require(targetType == root.addressType) {
                                    "قالب آدرس هدف با نوع کلید عمومی واردشده سازگار نیست."
                                }
                                val branchKey = root.derive(scanBranch)
                                val found = mutableListOf<String>()
                                val checked = scanEnd - scanStart + 1
                                var i = scanStart
                                while (i <= scanEnd) {
                                    val child = branchKey.derive(i)
                                    val derivedAddress = child.address()
                                    if (derivedAddress == scanTarget) {
                                        found.add("تطبیق قطعی: branch=$scanBranch، index=$i، path فرزند xpub: $scanBranch/$i")
                                    }
                                    i++
                                }
                                val message = "بررسی $checked اندیس کامل شد. " +
                                    if (found.isEmpty()) "در این بازه تطبیقی پیدا نشد." else found.joinToString("\n")
                                message to found
                            } catch (ex: Exception) {
                                "خطا: ${ex.message ?: "ورودی نامعتبر"}" to emptyList<String>()
                            }
                        }
                        status = result.first
                        matches = result.second
                        running = false
                    }
                }
                Text(status)
                matches.forEach { Text(it, color = MaterialTheme.colorScheme.primary) }
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("محدودیت‌های فنی", style = MaterialTheme.typography.titleMedium)
                Text("• نوع آدرس از پیشوند کلید تشخیص داده می‌شود: xpub=Legacy، ypub=Nested SegWit، zpub=Native SegWit.")
                Text("• xpub حسابی معمولاً در مسیر m/44'/0'/0' صادر می‌شود؛ در این حالت branch/indexهای 0/i بررسی می‌شوند.")
                Text("• از xpub نمی‌توان مسیرهای hardened یا عبارت بازیابی را استخراج کرد.")
                Text("• اگر xpub در اختیار نداری، این بخش نمی‌تواند با آدرس عمومی به‌تنهایی چیزی را بازیابی کند.")
                Text("• برنامه مجوز اینترنت ندارد؛ xpub در حافظه موقت صفحه استفاده می‌شود و ذخیره نمی‌شود.")
            }
        }
    }
}
