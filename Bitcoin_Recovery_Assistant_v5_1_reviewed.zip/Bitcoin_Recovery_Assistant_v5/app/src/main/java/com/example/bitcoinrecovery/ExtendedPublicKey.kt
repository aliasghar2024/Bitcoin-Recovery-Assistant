package com.example.bitcoinrecovery

import java.math.BigInteger

enum class AddressType { LEGACY, NESTED_SEGWIT, NATIVE_SEGWIT }

data class ExtendedPublicKey(
    val depth: Int,
    val parentFingerprint: ByteArray,
    val childNumber: Long,
    val chainCode: ByteArray,
    val publicKey: ByteArray,
    val addressType: AddressType
) {
    companion object {
        fun parse(encoded: String): ExtendedPublicKey {
            val all = Crypto.base58Decode(encoded.trim())
            require(all.size == 82) { "طول کلید توسعه‌یافته نامعتبر است." }
            val payload = all.copyOfRange(0, 78)
            val check = all.copyOfRange(78, 82)
            require(Crypto.sha256(Crypto.sha256(payload)).copyOfRange(0, 4).contentEquals(check)) {
                "Checksum کلید توسعه‌یافته نامعتبر است."
            }
            val version = payload.copyOfRange(0, 4)
            val type = when {
                version.contentEquals(byteArrayOf(0x04, 0x88.toByte(), 0xB2.toByte(), 0x1E)) -> AddressType.LEGACY
                version.contentEquals(byteArrayOf(0x04, 0x9D.toByte(), 0x7C, 0xB2.toByte())) -> AddressType.NESTED_SEGWIT
                version.contentEquals(byteArrayOf(0x04, 0xB2.toByte(), 0x47, 0x46)) -> AddressType.NATIVE_SEGWIT
                else -> throw IllegalArgumentException("نسخه پشتیبانی‌نشده است. فقط xpub/ypub/zpub شبکه اصلی پذیرفته می‌شود.")
            }
            require(payload[45].toInt() == 2 || payload[45].toInt() == 3) { "کلید عمومی فشرده نامعتبر است." }
            val pub = payload.copyOfRange(45, 78)
            Crypto.decodePub(pub)
            return ExtendedPublicKey(
                payload[4].toInt() and 0xff,
                payload.copyOfRange(5, 9),
                BigInteger(1, payload.copyOfRange(9, 13)).toLong(),
                payload.copyOfRange(13, 45),
                pub,
                type
            )
        }
    }

    fun derive(index: Long): ExtendedPublicKey {
        require(index in 0..0x7fffffffL) { "از کلید عمومی فقط اندیس non-hardened قابل مشتق‌سازی است." }
        val data = publicKey + byteArrayOf(
            (index ushr 24).toByte(), (index ushr 16).toByte(),
            (index ushr 8).toByte(), index.toByte()
        )
        val i = Crypto.hmac512(chainCode, data)
        val il = BigInteger(1, i.copyOfRange(0, 32))
        require(il < Crypto.N) { "اندیس نامعتبر؛ اندیس بعدی را امتحان کنید." }
        val childPoint = Crypto.add(Crypto.multiply(il), Crypto.decodePub(publicKey))
            ?: throw IllegalArgumentException("کلید فرزند بی‌نهایت شد؛ اندیس بعدی را امتحان کنید.")
        return ExtendedPublicKey(
            depth + 1, Crypto.hash160(publicKey).copyOfRange(0, 4), index,
            i.copyOfRange(32, 64), Crypto.pub(childPoint), addressType
        )
    }

    fun address(): String = when (addressType) {
        AddressType.LEGACY -> Crypto.p2pkh(publicKey)
        AddressType.NESTED_SEGWIT -> Crypto.p2shP2wpkh(publicKey)
        AddressType.NATIVE_SEGWIT -> Crypto.p2wpkh(publicKey)
    }
}
